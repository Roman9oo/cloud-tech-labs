const AWS = require("aws-sdk");

const dynamodb = new AWS.DynamoDB({
  region: "eu-central-1",
  apiVersion: "2012-08-10"
});

const replaceAll = (str, find, replace) => {
  return str.replace(new RegExp(find, "g"), replace);
};

exports.handler = async (event) => {
  // Розпарсимо тіло запиту
  const body = typeof event.body === "string" ? JSON.parse(event.body) : event.body;

  const id = replaceAll(body.title, " ", "-").toLowerCase();

  const params = {
    TableName: "roman-dev-courses",
    Item: {
      id: { S: id },
      title: { S: body.title },
      watchHref: { S: `http://www.pluralsight.com/courses/${id}` },
      authorId: { S: body.authorId },
      length: { S: body.length },
      category: { S: body.category }
    }
  };

  try {
    await dynamodb.putItem(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify(params.Item)
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};

